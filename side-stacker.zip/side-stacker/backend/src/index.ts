import server from './Server'

const port = 4000
server.listen(port)
console.log('Serving running on port: ', port)
