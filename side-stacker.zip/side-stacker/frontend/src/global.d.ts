declare module '*.png'
