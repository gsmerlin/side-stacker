const colors = {
  blue_1: '#16213E',
  blue_2: '#0F3460',
  blue_3: '#533483',
  red_1: '#EA5A47',
  red_2: '#E94560'
}

const theme = {
  colors
}

export default theme
